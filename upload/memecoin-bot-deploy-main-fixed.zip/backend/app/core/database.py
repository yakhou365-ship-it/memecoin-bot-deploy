"""
Async database session management.
Supports SQLite (dev) and PostgreSQL (prod) transparently.
"""
from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from sqlalchemy.ext.asyncio import (
    AsyncSession, async_sessionmaker, create_async_engine,
)

from .config import settings


# Engine creation
connect_args = {}
if settings.database_url.startswith("sqlite"):
    connect_args = {"check_same_thread": False}

engine = create_async_engine(
    settings.database_url,
    echo=False,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    connect_args=connect_args,
)

AsyncSessionLocal = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False, autoflush=False,
)


@asynccontextmanager
async def get_session() -> AsyncIterator[AsyncSession]:
    """Context manager that yields a DB session and rolls back on error."""
    session = AsyncSessionLocal()
    try:
        yield session
        await session.commit()
    except Exception:
        await session.rollback()
        raise
    finally:
        await session.close()


async def get_db() -> AsyncSession:
    """FastAPI dependency."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


def _ensure_trade_columns(sync_conn) -> None:
    """Add columns introduced after the initial schema to an existing DB.

    Alembic is a dependency but no migration environment is shipped, so
    ``create_all`` alone never evolves an existing ``trades`` table. These
    additive, nullable columns are safe to apply in place for both SQLite
    and PostgreSQL and preserve all existing data.
    """
    from sqlalchemy import inspect, text

    inspector = inspect(sync_conn)
    if "trades" not in inspector.get_table_names():
        return
    existing = {col["name"] for col in inspector.get_columns("trades")}
    if "peak_price" not in existing:
        sync_conn.execute(text("ALTER TABLE trades ADD COLUMN peak_price FLOAT"))


async def init_db() -> None:
    """Create all tables. Used for dev / first-run. Use Alembic for migrations in prod."""
    from .models import Base  # noqa
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.run_sync(_ensure_trade_columns)


async def close_db() -> None:
    await engine.dispose()
