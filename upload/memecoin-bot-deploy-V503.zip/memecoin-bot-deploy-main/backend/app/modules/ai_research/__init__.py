"""AI Research & Reasoning module."""
