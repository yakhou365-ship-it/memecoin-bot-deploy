"""On-chain Analysis module."""
