"""Market Scanner module."""
