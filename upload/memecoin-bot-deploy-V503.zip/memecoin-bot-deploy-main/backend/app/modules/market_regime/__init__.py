"""Market Regime Detection module."""
