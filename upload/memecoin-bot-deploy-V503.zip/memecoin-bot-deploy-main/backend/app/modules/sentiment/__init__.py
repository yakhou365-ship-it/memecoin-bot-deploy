"""Social Sentiment Analysis module."""
