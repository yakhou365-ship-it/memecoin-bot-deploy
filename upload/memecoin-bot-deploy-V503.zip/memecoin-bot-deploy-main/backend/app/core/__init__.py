"""Core infrastructure modules."""
